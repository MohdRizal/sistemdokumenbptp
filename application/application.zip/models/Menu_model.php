<?php

class Menu_model extends CI_Model{

    public function __construct(){
        $this->load->database();
    }

    public function getMenu()
    {
        return $this->db->get('jenis_dokumen')->result_array();
    }

    public function detail($type)
    {
        return $this->db->get_where('jenis_dokumen', ['id_jenis_dokumen' => $type])->row_array();
    }

}