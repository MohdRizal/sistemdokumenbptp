<?php

class History_model extends CI_Model{

    public function __construct(){
        $this->load->database();
    }

    public function login($username)
    {
        $data = [
            'username' => $username,
            'waktu_login' => date('Y-m-d H:i:s'),
            'ip_address' => $_SERVER['REMOTE_ADDR'],
        ];

        return $this->db->insert('login_history', $data);
    }

    public function access($username, $halaman, $kegiatan)
    {
        $data = [
            'username' => $username,
            'halaman' => $halaman,
            'kegiatan' => $kegiatan,
            'waktu' => date('Y-m-d H:i:s')
        ];

        return $this->db->insert('access_history', $data);
    }

    public function get_login($from, $to)
    {
        return $this->db->query("SELECT * FROM login_history WHERE waktu_login BETWEEN '$from' AND '$to'")->result_array();
    }

    public function get_akses($from, $to)
    {
        return $this->db->query("SELECT * FROM access_history WHERE waktu BETWEEN '$from' AND '$to'")->result_array();
    }

}