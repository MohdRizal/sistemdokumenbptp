<?php

class JenisKegiatan_model extends CI_Model{
    public function __construct(){
        $this->load->database();
    }

    public function get($id = FALSE)
    {
        if($id == FALSE)
        {
            return $this->db->get('jenis_kegiatan')->result_array();
        }

        return $this->db->get_where('jenis_kegiatan', ['id_jenis_kegiatan' => $id])->row_array();
    }

    public function save()
    {
        $data = [
            'nama_jenis_kegiatan' => $this->input->post('nama_jenis_kegiatan'),
            'tanggal_kegiatan' => $this->input->post('tanggal_kegiatan'),
            'keterangan' => $this->input->post('keterangan')
        ];

        return $this->db->insert('jenis_kegiatan', $data);
    }

    public function update()
    {
        $data = [
            'nama_jenis_kegiatan' => $this->input->post('nama_jenis_kegiatan'),
            'tanggal_kegiatan' => $this->input->post('tanggal_kegiatan'),
            'keterangan' => $this->input->post('keterangan')
        ];

        return $this->db->update('jenis_kegiatan', $data, ['id_jenis_kegiatan' => $this->input->post('id_jenis_kegiatan')]);
    }

    public function delete($id)
    {
        return $this->db->delete('jenis_kegiatan', ['id_jenis_kegiatan' => $id]);
    }
}