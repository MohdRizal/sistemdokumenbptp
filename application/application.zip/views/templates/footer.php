</div>
    </section>

<!-- Jquery Core Js -->
<script src="<?= base_url() ?>assets/jquery/jquery.min.js"></script>

<!-- Bootstrap Core Js -->
<script src="<?= base_url() ?>assets/bootstrap/js/bootstrap.js"></script>

<!-- Select Plugin Js -->
<script src="<?= base_url() ?>assets/bootstrap-select/js/bootstrap-select.js"></script>

<!-- Slimscroll Plugin Js -->
<script src="<?= base_url() ?>assets/jquery-slimscroll/jquery.slimscroll.js"></script>

<!-- Waves Effect Plugin Js -->
<script src="<?= base_url() ?>assets/node-waves/waves.js"></script>

<!-- Jquery DataTable Plugin Js -->
<script src="<?= base_url() ?>assets/jquery-datatable/jquery.dataTables.js"></script>
<script src="<?= base_url() ?>assets/jquery-datatable/skin/bootstrap/js/dataTables.bootstrap.js"></script>

<!-- Bootstrap Datepicker Plugin Js -->
<script src="<?= base_url() ?>assets/bootstrap-datepicker/js/bootstrap-datepicker.js"></script>

<!-- Custom Js -->
<script src="<?= base_url() ?>assets/js/admin.js"></script>
<script src="<?= base_url() ?>assets/js/pages/tables/jquery-datatable.js"></script>

<!-- Demo Js -->
<script src="<?= base_url() ?>assets/js/demo.js"></script>

<script>
	setInterval(function(){
			window.location.href="<?= base_url() ?>checkout/byebye";
	},600000)
</script>
</body>

</html>
