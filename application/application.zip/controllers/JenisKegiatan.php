<?php
class JenisKegiatan extends CI_Controller{

    public function __construct(){
        parent::__construct();
        //cek session
        if(!$this->session->userdata('logged_in'))
        {
            redirect('auth');
        }
        $this->load->model('JenisKegiatan_model');
        $this->load->model('FotoKegiatan_model');
    }

    public function index(){
        $data['jenis_kegiatan'] = $this->JenisKegiatan_model->get();
        $this->History_model->access($this->session->userdata('username'), 'foto kegiatan', 'mengunjungi halaman jenis foto kegiatan');
        $this->load->view('jenis-kegiatan/index', $data);
    }

    public function tambah(){
        if($this->session->userdata('role') == 2)
        {
            redirect('');
        }
        if($_POST)
        {
            if($this->JenisKegiatan_model->save())
            {
                $this->History_model->access($this->session->userdata('username'), 'foto kegiatan', 'menambah jenis foto kegiatan');
                $this->session->set_flashdata('alert', 'tambah');
                redirect('kegiatan');
            }
        }
        $this->History_model->access($this->session->userdata('username'), 'foto kegiatan', 'mengunjungi halaman tambah jenis foto kegiatan');
        $this->load->view('jenis-kegiatan/tambah');
    }

    public function update($id = FALSE){
        //tidak boleh akses langsung
        if($this->session->userdata('role') == 2)
        {
            redirect('');
        }
        if(!isset($_SERVER['HTTP_REFERER']))
        {
            redirect('kegiatan');
        }

        if($_POST)
        {
            if($this->JenisKegiatan_model->update())
            {
                $this->History_model->access($this->session->userdata('username'), 'foto kegiatan', 'mengupdate jenis foto kegiatan '.$_POST['nama_jenis_kegiatan']);
                $this->session->set_flashdata('alert', 'edit');
                redirect('kegiatan');
            }
        }

        $data['kegiatan'] = $this->JenisKegiatan_model->get($id);        
        $this->History_model->access($this->session->userdata('username'), 'foto kegiatan', 'mengunjungi halaman update jenis foto kegiatan');
        $this->load->view('jenis-kegiatan/edit', $data);
    }

    public function hapus($id){
        if($this->session->userdata('role') == 2)
        {
            redirect('');
        }
        //tidak boleh akses langsung
        if(!isset($_SERVER['HTTP_REFERER']))
        {
            redirect('kegiatan');
        }
        $photos = $this->FotoKegiatan_model->get($id);
        foreach($photos as $p){
            unlink('./assets/foto-kegiatan/'.$p['lokasi']);
        }
        if($this->JenisKegiatan_model->delete($id))
        {
            $this->History_model->access($this->session->userdata('username'), 'foto kegiatan', 'menghapus jenis foto kegiatan '.$photos['nama_jenis_kegiatan']);
            $this->session->set_flashdata('alert', 'hapus');
            redirect('kegiatan');
        }           
    }
}