<?php

class User extends CI_Controller{

    public function __construct(){
        parent::__construct();
        //cek session
        if(!$this->session->userdata('logged_in'))
        {
            redirect('auth');
        }

        if($this->session->userdata('role') != 0)
        {
            redirect('auth');   
        }
        $this->load->model('User_model');
    }

    public function index(){
        $data['user'] = $this->User_model->get();
        $this->History_model->access($this->session->userdata('username'), 'user', 'mengunjungi halaman user');
        $this->load->view('user/index', $data);
    }

    public function tambah(){
        //tidak boleh akses langsung
        if(!isset($_SERVER['HTTP_REFERER']))
        {
            redirect('account');
        }
        $this->load->library('form_validation');

        $this->form_validation->set_rules('username', 'Username', 'required|is_unique[user.username]',
            [
                'is_unique' => '<div class="alert bg-red alert-dismissible" role="alert">
                                    <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                                    Username sudah ada, coba username lain.
                                </div>'
            ]
        );
        if ($this->form_validation->run() == FALSE)
        {
            $this->History_model->access($this->session->userdata('username'), 'user', 'mengunjungi halaman tambah user');
            $this->load->view('user/tambah');
        }
        else
        {
            $data = [
                'username' => $this->input->post('username'),
                'password' => password_hash($this->input->post('password'), PASSWORD_BCRYPT),
                'role' => $this->input->post('role')
            ];

            if($this->User_model->save($data))
            {
                $this->History_model->access($this->session->userdata('username'), 'user', 'menambah user '.$this->input->post('username'));
                $this->session->set_flashdata('alert', 'tambah');
                redirect('account');
            }
        }
    }

    public function update($id){
        //tidak boleh akses langsung
        if(!isset($_SERVER['HTTP_REFERER']))
        {
            redirect('account');
        }
        if($_POST)
        {
            if($this->input->post('password') == '')
            {
                $data = [
                    'username' => $this->input->post('username'),
                    'role' => $this->input->post('role')
                ];
            }else{
                $data = [
                    'username' => $this->input->post('username'),
                    'password' => password_hash($this->input->post('password'), PASSWORD_BCRYPT),
                    'role' => $this->input->post('role')
                ];
            }
            if($this->User_model->update($data, $id))
            {
                $this->History_model->access($this->session->userdata('username'), 'user', 'mengupdate user '.$this->input->post('username'));
                $this->session->set_flashdata('alert', 'edit');
                redirect('account');
            }
        }
        $data['user'] = $this->User_model->get($id);
        $this->History_model->access($this->session->userdata('username'), 'user', 'mengunjungi halaman update user '.$data['user']['username']);
        $this->load->view('user/edit', $data);
    }

    public function hapus($id){
        //tidak boleh akses langsung
        if(!isset($_SERVER['HTTP_REFERER']))
        {
            redirect('account');
        }
        //untuk keperluan log akses
        $data['user'] = $this->User_model->get($id);

        if($this->User_model->delete($id))
        {
            $this->History_model->access($this->session->userdata('username'), 'user', 'menghapus user '.$data['user']['username']);
            $this->session->set_flashdata('alert', 'hapus');
            redirect('account');
        }
    }

}